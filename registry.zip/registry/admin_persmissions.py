class RoleBasedAdminMixin:
    """
    Enforces role-based permissions for Django admin.
    Assumes request.user.role exists.
    """

    def has_view_permission(self, request, obj=None):
        return (
            request.user.is_authenticated and
            request.user.role in ('admin', 'clerk', 'viewer')
        )

    def has_add_permission(self, request):
        return request.user.role in ('admin', 'clerk')

    def has_change_permission(self, request, obj=None):
        return request.user.role in ('admin', 'clerk')

    def has_delete_permission(self, request, obj=None):
        return request.user.role == 'admin'

    def get_readonly_fields(self, request, obj=None):
        if request.user.role == 'viewer':
            return [field.name for field in self.model._meta.fields]
        return []
