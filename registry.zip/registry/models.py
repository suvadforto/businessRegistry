from django.contrib.auth.models import AbstractUser

from django.db import models

class Business(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('suspended', 'Suspended'),
    ]

    name = models.CharField(max_length=255)
    registration_number = models.CharField(max_length=100, unique=True)
    tax_number = models.CharField(max_length=100, blank=True, null=True)
    industry = models.CharField(max_length=150, blank=True, null=True)
    legal_form = models.CharField(max_length=100, blank=True, null=True)

    address = models.TextField(blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    postal_code = models.CharField(max_length=20, blank=True, null=True)

    phone = models.CharField(max_length=50, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)

    status = models.CharField(
        max_length=50,
        choices=STATUS_CHOICES,
        default='active'
    )

    date_registered = models.DateField()
    notes = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.registration_number})"
        



class Owner(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    personal_id = models.CharField(max_length=100, blank=True, null=True)

    address = models.TextField(blank=True, null=True)
    phone = models.CharField(max_length=50, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

#BusinessOwner (Many-to-Many with extra fields)
class BusinessOwner(models.Model):
    business = models.ForeignKey(
        Business,
        on_delete=models.CASCADE,
        related_name='ownerships'
    )
    owner = models.ForeignKey(
        Owner,
        on_delete=models.CASCADE,
        related_name='businesses'
    )
    ownership_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        blank=True,
        null=True
    )

    class Meta:
        unique_together = ('business', 'owner')

    def __str__(self):
        return f"{self.owner} → {self.business}"

class License(models.Model):
    STATUS_CHOICES = [
        ('valid', 'Valid'),
        ('expired', 'Expired'),
        ('revoked', 'Revoked'),
    ]

    business = models.ForeignKey(
        Business,
        on_delete=models.CASCADE,
        related_name='licenses'
    )

    license_type = models.CharField(max_length=150)
    license_number = models.CharField(max_length=100)
    issue_date = models.DateField(blank=True, null=True)
    expiry_date = models.DateField(blank=True, null=True)

    status = models.CharField(
        max_length=50,
        choices=STATUS_CHOICES
    )

    notes = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.license_type} – {self.business.name}"


class Inspection(models.Model):
    RESULT_CHOICES = [
        ('passed', 'Passed'),
        ('failed', 'Failed'),
    ]

    business = models.ForeignKey(
        Business,
        on_delete=models.CASCADE,
        related_name='inspections'
    )

    inspection_date = models.DateField()
    inspector_name = models.CharField(max_length=150)
    result = models.CharField(max_length=50, choices=RESULT_CHOICES)
    remarks = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.business.name} – {self.inspection_date}"

class Document(models.Model):
    business = models.ForeignKey(
        Business,
        on_delete=models.CASCADE,
        related_name='documents'
    )

    document_type = models.CharField(max_length=100)
    file = models.FileField(upload_to='documents/%Y/%m/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.document_type} – {self.business.name}"

class User(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('clerk', 'Clerk'),
        ('viewer', 'Viewer'),
    ]

    role = models.CharField(
        max_length=50,
        choices=ROLE_CHOICES,
        default='viewer'
    )

class AuditLog(models.Model):
    ACTION_CHOICES = [
        ('create', 'Create'),
        ('update', 'Update'),
        ('delete', 'Delete'),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    action = models.CharField(
        max_length=50,
        choices=ACTION_CHOICES
    )

    table_name = models.CharField(max_length=100)
    record_id = models.PositiveIntegerField()
    action_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.action} – {self.table_name} ({self.record_id})"

    class Meta:
        indexes = [
            models.Index(fields=['table_name', 'record_id']),
            models.Index(fields=['action_time']),
        ]


# Create your models here.
